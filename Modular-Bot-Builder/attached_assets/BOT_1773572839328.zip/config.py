# core/config.py
import os
from pathlib import Path

BASE_DIR = Path(__file__).parent.parent
DATA_DIR = BASE_DIR / "data"

TOKEN = "8264884534:AAEEsMvirgEvF4CKG7dSx89KSHRUzOyrsWw"  # сюда вставь токен

# Проверка папки для данных
if not DATA_DIR.exists():
    DATA_DIR.mkdir(parents=True)