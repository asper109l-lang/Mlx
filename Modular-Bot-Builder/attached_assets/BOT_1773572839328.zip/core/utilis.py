from telegram import ChatPermissions
from core.mods import is_enabled as module_enabled
from core.storage import ChatStorage

async def warn_user(chat_id: int, user_id: int, reason: str = "Нарушение правил"):
    storage = ChatStorage(chat_id)
    if not module_enabled(chat_id, "warns"):
        return False
    user = storage.load_user(user_id)
    user["warns"] = user.get("warns", 0) + 1
    storage.save_user(user_id, user)
    return user["warns"]

async def ban_user(bot, chat_id: int, user_id: int, until_date=None):
    storage = ChatStorage(chat_id)
    if not module_enabled(chat_id, "ban"):
        return False
    try:
        await bot.ban_chat_member(chat_id, user_id, until_date=until_date)
        return True
    except:
        return False

async def unban_user(bot, chat_id: int, user_id: int):
    try:
        await bot.unban_chat_member(chat_id, user_id)
        return True
    except:
        return False

async def mute_user(bot, chat_id: int, user_id: int, until_date=None):
    storage = ChatStorage(chat_id)
    if not module_enabled(chat_id, "mute"):
        return False
    try:
        await bot.restrict_chat_member(
            chat_id, user_id,
            permissions=ChatPermissions(can_send_messages=False),
            until_date=until_date
        )
        return True
    except:
        return False

async def unmute_user(bot, chat_id: int, user_id: int):
    try:
        await bot.restrict_chat_member(
            chat_id, user_id,
            permissions=ChatPermissions(can_send_messages=True)
        )
        return True
    except:
        return False

async def delete_message(bot, chat_id: int, message_id: int):
    storage = ChatStorage(chat_id)
    if not module_enabled(chat_id, "autodelete"):
        return False
    try:
        await bot.delete_message(chat_id, message_id)
        return True
    except:
        return False