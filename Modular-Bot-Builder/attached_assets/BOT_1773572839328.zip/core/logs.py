# logs.py
from collections import defaultdict
from datetime import datetime

class LogsManager:
    def __init__(self):
        # словарь: chat_id -> список логов
        self.logs = defaultdict(list)

    def add_log(self, chat_id: int, action: str, user_id: int = None, reason: str = None):
        """Добавляем лог действия"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = {
            "time": timestamp,
            "action": action,
            "user_id": user_id,
            "reason": reason
        }
        self.logs[chat_id].append(log_entry)

    def get_logs(self, chat_id: int, limit: int = 50):
        """Получаем последние N логов"""
        return self.logs[chat_id][-limit:]

    def clear_logs(self, chat_id: int):
        """Очищаем логи чата"""
        self.logs[chat_id] = []

# пример использования:
# logs = LogsManager()
# logs.add_log(chat_id=123, action="ban", user_id=456, reason="спам")
# print(logs.get_logs(123))