from bot import Bot
from storage import Storage
from roles import Roles
from admins import Admins
from mods import Mods
from commands import Commands
from actions import Action
from moderation import Moderation
from dynamic_buttons import DynamicButtons
from utils import Utils
from logs import Logs

class Core:
    def __init__(self, token):
        self.token = token
        self.bot = Bot(self.token)
        # инициализация остальных модулей

    async def run(self):
        await self.bot.start()