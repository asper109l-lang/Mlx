# modules/moderation/commands.py
from telegram import Update
from telegram.ext import ContextTypes
from core.moderation import moderation

# ------------------ команды ------------------
async def handle_mod_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Обрабатывает команды модерации без слеша.
    Использование:
    - через reply на сообщение пользователя
    - или с указанием user_id в тексте
    Команды: бан, разбан, мут, варн
    """
    text = update.message.text.lower()
    reply_user = update.message.reply_to_message.from_user if update.message.reply_to_message else None

    if reply_user:
        target_id = reply_user.id
    else:
        # попытка взять user_id из текста
        parts = text.split()
        if len(parts) < 2:
            await update.message.reply_text("Нужно указать пользователя через reply или user_id")
            return
        try:
            target_id = int(parts[1])
        except ValueError:
            await update.message.reply_text("Неверный user_id")
            return

    chat_id = update.effective_chat.id

    # ------------------ команды ------------------
    if "бан" in text:
        moderation.ban_user(chat_id, target_id, reason="Авто-бан")
        await update.message.reply_text(f"Пользователь {target_id} забанен ✅")
    elif "разбан" in text:
        moderation.unban_user(chat_id, target_id)
        await update.message.reply_text(f"Пользователь {target_id} разбанен ✅")
    elif "мут" in text:
        moderation.mute_user(chat_id, target_id, minutes=10, reason="Авто-мут")
        await update.message.reply_text(f"Пользователь {target_id} замучен на 10 минут ✅")
    elif "варн" in text:
        moderation.warn_user(chat_id, target_id, reason="Авто-варн")
        await update.message.reply_text(f"Пользователь {target_id} получил предупреждение ⚠")
    else:
        await update.message.reply_text("Неизвестная команда модерации")