import asyncio
from pathlib import Path
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

# Импорт из того же пакета
import core.config as config
from core.utils import load_json, save_json
from core.admins import Admins

TOKEN = config.TOKEN
DATA_DIR = config.DATA_DIR

# ------------------ данные чата ------------------
def get_chat_data(chat_id):
    chat_folder = Path(DATA_DIR) / f"chat_{chat_id}"
    chat_folder.mkdir(parents=True, exist_ok=True)

    settings_file = chat_folder / "settings.json"
    users_file = chat_folder / "users.json"

    settings = load_json(settings_file, default={"modules": {}, "owner_id": None})
    users = load_json(users_file, default={})

    return settings, users, settings_file, users_file

# ------------------ админ и роли ------------------
async def auto_set_owner(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    settings, users, settings_file, users_file = get_chat_data(chat_id)
    admins = Admins(chat_id)

    if not settings.get("owner_id"):
        owner_id = update.effective_user.id
        settings["owner_id"] = owner_id
        admins.set_owner(owner_id)
        save_json(settings_file, settings)
        await update.message.reply_text(f"Владелец группы установлен: {update.effective_user.first_name}")

# ------------------ обработка команд ------------------
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await auto_set_owner(update, context)
    await update.message.reply_text("Бот запущен! Админ автоматически определен.")

# ------------------ обработка всех сообщений ------------------
async def handle_all_messages(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    settings, users, settings_file, users_file = get_chat_data(chat_id)
    admins = Admins(chat_id)

    text = update.message.text
    user_id = update.effective_user.id

    # здесь можно подключать динамические модули: бан, мут, варн, роли
    print(f"[{chat_id}] {user_id}: {text}")

    # пример простой проверки администратора
    if admins.is_admin(user_id):
        print(f"Админ {user_id} написал сообщение.")

# ------------------ основной запуск ------------------
def main():
    app = Application.builder().token(TOKEN).build()

    # базовые команды
    app.add_handler(CommandHandler("start", start_command))

    # обработка любых текстовых сообщений
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_all_messages))

    print("Бот запущен...")
    app.run_polling()

if __name__ == "__main__":
    main()