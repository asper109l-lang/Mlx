import json
from pathlib import Path
from copy import deepcopy

class ChatStorage:
    DEFAULT_DATA = {
        "users": {},
        "admins": {},
        "modules": {},
        "owner": None
    }

    def __init__(self, chat_id: int, base_dir="data/chats"):
        self.chat_id = chat_id
        self.chat_folder = Path(base_dir)
        self.chat_folder.mkdir(parents=True, exist_ok=True)
        self.file_path = self.chat_folder / f"{chat_id}.json"
        self.data = self.load_chat()

    def load_chat(self):
        if not self.file_path.exists():
            self.save_chat(deepcopy(self.DEFAULT_DATA))
        with open(self.file_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def save_chat(self, data=None):
        if data is not None:
            self.data = data
        with open(self.file_path, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=2, ensure_ascii=False)

    # ------------------ Users ------------------
    def load_user(self, user_id: int):
        return self.data["users"].get(str(user_id), {})

    def save_user(self, user_id: int, user_data: dict):
        self.data["users"][str(user_id)] = user_data
        self.save_chat()

    # ------------------ Admins ------------------
    def set_admin(self, user_id: int, level=1):
        self.data["admins"][str(user_id)] = level
        self.save_chat()

    def remove_admin(self, user_id: int):
        self.data["admins"].pop(str(user_id), None)
        self.save_chat()

    def is_admin(self, user_id: int):
        return str(user_id) in self.data["admins"]

    # ------------------ Modules ------------------
    def enable_module(self, module_name: str):
        self.data["modules"][module_name] = True
        self.save_chat()

    def disable_module(self, module_name: str):
        self.data["modules"][module_name] = False
        self.save_chat()

    def is_module_enabled(self, module_name: str):
        return self.data["modules"].get(module_name, False)

    # ------------------ Owner ------------------
    def set_owner(self, user_id: int):
        if self.data["owner"] is None:
            self.data["owner"] = user_id
            self.save_chat()
        return self.data["owner"]

    def get_owner(self):
        return self.data.get("owner")