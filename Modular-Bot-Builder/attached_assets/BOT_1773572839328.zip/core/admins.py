import os
import json

DATA_DIR = "data/chats"

class Admins:
    def __init__(self, chat_id: int):
        self.chat_id = chat_id
        self.chat_path = os.path.join(DATA_DIR, str(chat_id))
        os.makedirs(self.chat_path, exist_ok=True)
        self.file_path = os.path.join(self.chat_path, "admins.json")
        self.data = self._load()

    def _load(self):
        if not os.path.exists(self.file_path):
            return {"owner": None, "admins": []}
        try:
            with open(self.file_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {"owner": None, "admins": []}

    def _save(self):
        with open(self.file_path, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)

    def set_owner(self, user_id: int):
        if self.data["owner"] is None:
            self.data["owner"] = user_id
            self._save()
        return self.data["owner"]

    def add_admin(self, user_id: int):
        if user_id not in self.data["admins"] and user_id != self.data["owner"]:
            self.data["admins"].append(user_id)
            self._save()

    def remove_admin(self, user_id: int):
        if user_id in self.data["admins"]:
            self.data["admins"].remove(user_id)
            self._save()

    def is_owner(self, user_id: int):
        return self.data["owner"] == user_id

    def is_admin(self, user_id: int):
        return user_id in self.data["admins"] or self.is_owner(user_id)

    def promote(self, user_id: int):
        """Повысить пользователя до админа"""
        self.add_admin(user_id)

    def demote(self, user_id: int):
        """Понизить админа (не владельца!)"""
        if not self.is_owner(user_id):
            self.remove_admin(user_id)