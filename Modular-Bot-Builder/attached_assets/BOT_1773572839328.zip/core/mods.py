import json
from pathlib import Path
from core.utils import load_json, save_json

class Modules:
    DEFAULT_MODULES = {
        "warns": True,
        "ban": True,
        "mute": True,
        "rep": True,
        "autodelete": True,
        "autoban_non_subs": False,
        "logging": True,
    }

    def __init__(self, chat_id: int, data_dir="data/chats"):
        self.chat_id = chat_id
        self.chat_folder = Path(data_dir) / str(chat_id)
        self.chat_folder.mkdir(parents=True, exist_ok=True)
        self.file_path = self.chat_folder / "modules.json"
        self.modules = self.load_modules()

    def load_modules(self):
        return load_json(self.file_path, default=self.DEFAULT_MODULES.copy())

    def save_modules(self):
        save_json(self.file_path, self.modules)

    def enable(self, module_name: str):
        self.modules[module_name] = True
        self.save_modules()

    def disable(self, module_name: str):
        self.modules[module_name] = False
        self.save_modules()

    def toggle(self, module_name: str):
        self.modules[module_name] = not self.modules.get(module_name, False)
        self.save_modules()

    def is_enabled(self, module_name: str) -> bool:
        return self.modules.get(module_name, False)