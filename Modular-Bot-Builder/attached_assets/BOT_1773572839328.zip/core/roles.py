# modules/chat_control/roles.py
from core.utils import load_json, save_json
from core.config import DATA_DIR

def add_role(chat_id, user_id, role):
    users_file = DATA_DIR / f"chat_{chat_id}" / "users.json"
    users = load_json(users_file, default={})
    users[str(user_id)] = role
    save_json(users_file, users)

def remove_role(chat_id, user_id):
    users_file = DATA_DIR / f"chat_{chat_id}" / "users.json"
    users = load_json(users_file, default={})
    users.pop(str(user_id), None)
    save_json(users_file, users)

def get_role(chat_id, user_id):
    users_file = DATA_DIR / f"chat_{chat_id}" / "users.json"
    users = load_json(users_file, default={})
    return users.get(str(user_id))