from telegram import ChatPermissions
from core import mods, storage

async def warn_user(bot, chat_id: int, user_id: int, reason: str = "Нарушение правил"):
    if not mods.Mods().is_enabled(chat_id, "warns"):
        return False
    data = storage.Storage().load_user(chat_id, user_id)
    if data is None:
        data = {}
    data["warns"] = data.get("warns", 0) + 1
    storage.Storage().save_user(chat_id, user_id, data)
    return data["warns"]

async def ban_user(bot, chat_id: int, user_id: int, until_date=None):
    if not mods.Mods().is_enabled(chat_id, "ban"):
        return False
    try:
        await bot.ban_chat_member(chat_id, user_id, until_date=until_date)
        return True
    except Exception:
        return False

async def unban_user(bot, chat_id: int, user_id: int):
    try:
        await bot.unban_chat_member(chat_id, user_id)
        return True
    except Exception:
        return False

async def mute_user(bot, chat_id: int, user_id: int, until_date=None):
    if not mods.Mods().is_enabled(chat_id, "mute"):
        return False
    try:
        await bot.restrict_chat_member(
            chat_id, user_id,
            permissions=ChatPermissions(can_send_messages=False),
            until_date=until_date
        )
        return True
    except Exception:
        return False

async def unmute_user(bot, chat_id: int, user_id: int):
    try:
        await bot.restrict_chat_member(
            chat_id, user_id,
            permissions=ChatPermissions(can_send_messages=True)
        )
        return True
    except Exception:
        return False

async def delete_message(bot, chat_id: int, message_id: int):
    if not mods.Mods().is_enabled(chat_id, "autodelete"):
        return False
    try:
        await bot.delete_message(chat_id, message_id)
        return True
    except Exception:
        return False