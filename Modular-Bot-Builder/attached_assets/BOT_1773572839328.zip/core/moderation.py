# modules/moderation/moderation.py
import asyncio
from datetime import datetime, timedelta
from core.utils import load_json, save_json
from core.config import DATA_DIR

# ------------------ пути к файлам ------------------
def get_chat_files(chat_id):
    chat_folder = DATA_DIR / f"chat_{chat_id}"
    chat_folder.mkdir(exist_ok=True)
    users_file = chat_folder / "users.json"
    logs_file = chat_folder / "logs.json"
    return users_file, logs_file

# ------------------ действия модератора ------------------
def warn_user(chat_id, user_id, reason="Без причины"):
    users_file, logs_file = get_chat_files(chat_id)
    users = load_json(users_file, default={})
    logs = load_json(logs_file, default={})
    
    if str(user_id) not in users:
        users[str(user_id)] = {"warns": 0, "muted_until": None, "banned": False}
    
    users[str(user_id)]["warns"] += 1
    save_json(users_file, users)
    
    # логируем
    logs.setdefault(str(datetime.now()), f"User {user_id} warned: {reason}")
    save_json(logs_file, logs)

def ban_user(chat_id, user_id, reason="Без причины"):
    users_file, logs_file = get_chat_files(chat_id)
    users = load_json(users_file, default={})
    logs = load_json(logs_file, default={})
    
    users.setdefault(str(user_id), {"warns": 0, "muted_until": None})
    users[str(user_id)]["banned"] = True
    save_json(users_file, users)
    
    logs.setdefault(str(datetime.now()), f"User {user_id} banned: {reason}")
    save_json(logs_file, logs)

def unban_user(chat_id, user_id):
    users_file, _ = get_chat_files(chat_id)
    users = load_json(users_file, default={})
    
    if str(user_id) in users:
        users[str(user_id)]["banned"] = False
        save_json(users_file, users)

def mute_user(chat_id, user_id, minutes=10, reason="Без причины"):
    users_file, logs_file = get_chat_files(chat_id)
    users = load_json(users_file, default={})
    logs = load_json(logs_file, default={})
    
    mute_until = datetime.now() + timedelta(minutes=minutes)
    users.setdefault(str(user_id), {"warns": 0, "banned": False})
    users[str(user_id)]["muted_until"] = mute_until.isoformat()
    save_json(users_file, users)
    
    logs.setdefault(str(datetime.now()), f"User {user_id} muted until {mute_until} reason: {reason}")
    save_json(logs_file, logs)

def check_mute(chat_id, user_id):
    users_file, _ = get_chat_files(chat_id)
    users = load_json(users_file, default={})
    user = users.get(str(user_id))
    if not user or not user.get("muted_until"):
        return False
    return datetime.fromisoformat(user["muted_until"]) > datetime.now()

def check_ban(chat_id, user_id):
    users_file, _ = get_chat_files(chat_id)
    users = load_json(users_file, default={})
    return users.get(str(user_id), {}).get("banned", False)