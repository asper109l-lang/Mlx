# modules/panel/dynamic_buttons.py
from telegram import InlineKeyboardButton, InlineKeyboardMarkup

def create_buttons(button_dict):
    # button_dict = {"Текст1": "callback1", "Текст2": "callback2"}
    buttons = [[InlineKeyboardButton(text=k, callback_data=v)] for k, v in button_dict.items()]
    return InlineKeyboardMarkup(buttons)