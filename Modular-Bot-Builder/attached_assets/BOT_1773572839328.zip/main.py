import asyncio
import sys
import os

# Добавляем родительскую папку в sys.path, чтобы core был виден как пакет
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.core import Core
import core.config as config  # теперь точно найдётся

async def main():
    core_bot = Core(config.TOKEN)
    await core_bot.run()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("Бот остановлен вручную")